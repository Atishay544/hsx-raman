# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: search.spec.ts >> Search page >> shows results for a query
- Location: e2e\search.spec.ts:10:7

# Error details

```
Error: locator.isVisible: Error: strict mode violation: locator('text=/Products|No results/') resolved to 3 elements:
    1) <a href="/products" class="relative px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 text-gray-600 hover:text-gray-900 hover:bg-gray-50">All Products</a> aka getByRole('banner').getByText('All Products')
    2) <p class="text-lg mb-2">…</p> aka getByText('No results for "shirt"')
    3) <a href="/products" class="text-sm hover:text-white transition">All Products</a> aka getByRole('link', { name: 'All Products', exact: true })

Call log:
    - checking visibility of locator('text=/Products|No results/')

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - button [ref=e6]:
          - img [ref=e7]
        - link "STORE" [ref=e8] [cursor=pointer]:
          - /url: /
        - generic [ref=e9]:
          - link [ref=e10] [cursor=pointer]:
            - /url: /search
            - img [ref=e11]
          - link [ref=e14] [cursor=pointer]:
            - /url: /cart
            - img [ref=e15]
          - button [ref=e19]:
            - img [ref=e21]
    - main [ref=e24]:
      - generic [ref=e25]:
        - generic [ref=e27]:
          - img [ref=e28]
          - textbox "Search products, categories…" [active] [ref=e31]: shirt
          - button "Search" [ref=e32]
        - generic [ref=e33]:
          - paragraph [ref=e34]: No results for "shirt"
          - link "Browse all products" [ref=e35] [cursor=pointer]:
            - /url: /products
    - contentinfo [ref=e36]:
      - generic [ref=e37]:
        - generic [ref=e38]:
          - heading "STORE" [level=2] [ref=e39]
          - paragraph [ref=e40]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e41]:
            - link "IG" [ref=e42] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e43] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e44] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e45]:
          - heading "Shop" [level=3] [ref=e46]
          - list [ref=e47]:
            - listitem [ref=e48]:
              - link "All Products" [ref=e49] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e50]:
              - link "Tom & Jerry" [ref=e51] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e52]:
              - link "Hero's" [ref=e53] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e54]:
              - link "Lamps" [ref=e55] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e56]:
              - link "Key Ring" [ref=e57] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e58]:
              - link "Dogs" [ref=e59] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e60]:
          - heading "Account" [level=3] [ref=e61]
          - list [ref=e62]:
            - listitem [ref=e63]:
              - link "My Orders" [ref=e64] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e65]:
              - link "Wishlist" [ref=e66] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e67]:
              - link "My Profile" [ref=e68] [cursor=pointer]:
                - /url: /account
        - generic [ref=e69]:
          - heading "Support" [level=3] [ref=e70]
          - list [ref=e71]:
            - listitem [ref=e72]:
              - link "Contact Us" [ref=e73] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e74]:
              - link "FAQs" [ref=e75] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e76]:
              - link "Refund & Returns" [ref=e77] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e78]:
              - link "Shipping Info" [ref=e79] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e80]:
          - heading "Legal" [level=3] [ref=e81]
          - list [ref=e82]:
            - listitem [ref=e83]:
              - link "Privacy Policy" [ref=e84] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e85]:
              - link "Terms of Service" [ref=e86] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e87]:
        - paragraph [ref=e88]: © 2026 Store. All rights reserved.
        - generic [ref=e89]:
          - link "orders@aitalk247.com" [ref=e90] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e91] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e93]:
      - img [ref=e94]
  - button "Open Next.js Dev Tools" [ref=e101] [cursor=pointer]:
    - img [ref=e102]
  - alert [ref=e105]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Search page', () => {
  4  |   test('shows empty state when no query', async ({ page }) => {
  5  |     await page.goto('/search')
  6  |     await expect(page).toHaveTitle(/Search/)
  7  |     await expect(page.locator('text=Start typing to search')).toBeVisible()
  8  |   })
  9  | 
  10 |   test('shows results for a query', async ({ page }) => {
  11 |     await page.goto('/search?q=shirt')
  12 |     await expect(page).toHaveTitle(/Search: shirt/)
  13 |     // Either results or "no results" message
> 14 |     const hasResults = await page.locator('text=/Products|No results/').isVisible()
     |                                                                         ^ Error: locator.isVisible: Error: strict mode violation: locator('text=/Products|No results/') resolved to 3 elements:
  15 |     expect(hasResults).toBe(true)
  16 |   })
  17 | 
  18 |   test('search input has correct default value from URL', async ({ page }) => {
  19 |     await page.goto('/search?q=test')
  20 |     const input = page.locator('input[type="search"], input[placeholder*="Search"]').first()
  21 |     await expect(input).toHaveValue('test')
  22 |   })
  23 | 
  24 |   test('typing in search input updates URL', async ({ page }) => {
  25 |     await page.goto('/search')
  26 |     const input = page.locator('input').first()
  27 |     await input.fill('laptop')
  28 |     // Wait for debounce / form submit
  29 |     await page.keyboard.press('Enter')
  30 |     await expect(page).toHaveURL(/q=laptop/)
  31 |   })
  32 | })
  33 | 
```