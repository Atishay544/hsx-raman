# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: cart.spec.ts >> Add to cart flow >> adding item to cart updates cart count
- Location: e2e\cart.spec.ts:43:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.isEnabled: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('button').filter({ hasText: /Add to Cart/i }).first()

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - button [ref=e6]:
          - img [ref=e7]
        - link "STORE" [ref=e8] [cursor=pointer]:
          - /url: /
        - generic [ref=e9]:
          - link [ref=e10] [cursor=pointer]:
            - /url: /search
            - img [ref=e11]
          - link [ref=e14] [cursor=pointer]:
            - /url: /cart
            - img [ref=e15]
          - button [ref=e19]:
            - img [ref=e21]
    - main [ref=e24]:
      - generic [ref=e25]:
        - navigation [ref=e26]:
          - link "Home" [ref=e27] [cursor=pointer]:
            - /url: /
          - generic [ref=e28]: /
          - generic [ref=e29]: milk
        - generic [ref=e30]:
          - generic [ref=e32]: 📦
          - generic [ref=e33]:
            - heading "milk" [level=1] [ref=e34]
            - generic [ref=e35]:
              - generic [ref=e37]: $1,200.00
              - paragraph [ref=e38]: inclusive of all taxes
            - generic [ref=e40]: Out of Stock
            - button "Out of Stock" [disabled] [ref=e42]
            - generic [ref=e43]:
              - generic [ref=e44]:
                - img [ref=e45]
                - generic [ref=e50]: Free Delivery
              - generic [ref=e51]:
                - img [ref=e52]
                - generic [ref=e57]: Easy Returns
              - generic [ref=e58]:
                - img [ref=e59]
                - generic [ref=e61]: Secure Pay
        - generic [ref=e62]:
          - heading "Customer Reviews" [level=2] [ref=e64]
          - paragraph [ref=e65]: No reviews yet. Be the first!
    - contentinfo [ref=e66]:
      - generic [ref=e67]:
        - generic [ref=e68]:
          - heading "STORE" [level=2] [ref=e69]
          - paragraph [ref=e70]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e71]:
            - link "IG" [ref=e72] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e73] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e74] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e75]:
          - heading "Shop" [level=3] [ref=e76]
          - list [ref=e77]:
            - listitem [ref=e78]:
              - link "All Products" [ref=e79] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e80]:
              - link "Tom & Jerry" [ref=e81] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e82]:
              - link "Hero's" [ref=e83] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e84]:
              - link "Lamps" [ref=e85] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e86]:
              - link "Key Ring" [ref=e87] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e88]:
              - link "Dogs" [ref=e89] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e90]:
          - heading "Account" [level=3] [ref=e91]
          - list [ref=e92]:
            - listitem [ref=e93]:
              - link "My Orders" [ref=e94] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e95]:
              - link "Wishlist" [ref=e96] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e97]:
              - link "My Profile" [ref=e98] [cursor=pointer]:
                - /url: /account
        - generic [ref=e99]:
          - heading "Support" [level=3] [ref=e100]
          - list [ref=e101]:
            - listitem [ref=e102]:
              - link "Contact Us" [ref=e103] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e104]:
              - link "FAQs" [ref=e105] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e106]:
              - link "Refund & Returns" [ref=e107] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e108]:
              - link "Shipping Info" [ref=e109] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e110]:
          - heading "Legal" [level=3] [ref=e111]
          - list [ref=e112]:
            - listitem [ref=e113]:
              - link "Privacy Policy" [ref=e114] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e115]:
              - link "Terms of Service" [ref=e116] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e117]:
        - paragraph [ref=e118]: © 2026 Store. All rights reserved.
        - generic [ref=e119]:
          - link "orders@aitalk247.com" [ref=e120] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e121] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e123]:
      - img [ref=e124]
  - button "Open Next.js Dev Tools" [ref=e131] [cursor=pointer]:
    - img [ref=e132]
  - alert [ref=e135]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Cart page', () => {
  4  |   test('shows empty state when cart is empty', async ({ page }) => {
  5  |     // Clear localStorage cart before visiting
  6  |     await page.goto('/cart')
  7  |     // If cart store has no items (fresh browser), shows empty state
  8  |     const body = await page.content()
  9  |     if (body.includes('Your cart is empty')) {
  10 |       await expect(page.locator('text=Your cart is empty')).toBeVisible()
  11 |       await expect(page.getByRole('link', { name: /Shop Now/i })).toBeVisible()
  12 |     }
  13 |   })
  14 | 
  15 |   test('cart page has correct title', async ({ page }) => {
  16 |     await page.goto('/cart')
  17 |     await expect(page).toHaveTitle(/My Store/)
  18 |   })
  19 | 
  20 |   test('empty cart shop now link goes to products', async ({ page }) => {
  21 |     await page.goto('/cart')
  22 |     const shopLink = page.getByRole('link', { name: /Shop Now/i })
  23 |     if (await shopLink.isVisible()) {
  24 |       await shopLink.click()
  25 |       await expect(page).toHaveURL('/products')
  26 |     }
  27 |   })
  28 | })
  29 | 
  30 | test.describe('Add to cart flow', () => {
  31 |   test('add to cart button visible on product page', async ({ page }) => {
  32 |     await page.goto('/products')
  33 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  34 |     const href = await firstProduct.getAttribute('href')
  35 |     if (href) {
  36 |       await page.goto(href)
  37 |       // Add to cart button should be visible
  38 |       const addBtn = page.locator('button', { hasText: /Add to Cart|Out of Stock/i }).first()
  39 |       await expect(addBtn).toBeVisible()
  40 |     }
  41 |   })
  42 | 
  43 |   test('adding item to cart updates cart count', async ({ page }) => {
  44 |     await page.goto('/products')
  45 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  46 |     const href = await firstProduct.getAttribute('href')
  47 |     if (href) {
  48 |       await page.goto(href)
  49 |       const addBtn = page.locator('button', { hasText: /Add to Cart/i }).first()
> 50 |       if (await addBtn.isEnabled()) {
     |                        ^ Error: locator.isEnabled: Test timeout of 30000ms exceeded.
  51 |         await addBtn.click()
  52 |         // Cart count in header should update
  53 |         await page.goto('/cart')
  54 |         await expect(page.locator('text=/Cart \\(/i')).toBeVisible()
  55 |       }
  56 |     }
  57 |   })
  58 | })
  59 | 
```