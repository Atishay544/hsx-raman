# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth.spec.ts >> Auth flow >> checkout redirect when not logged in
- Location: e2e\auth.spec.ts:29:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.isEnabled: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('button').filter({ hasText: /Add to Cart/i }).first()

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - link "STORE" [ref=e6] [cursor=pointer]:
          - /url: /
        - navigation [ref=e7]:
          - link "Tom & Jerry" [ref=e9] [cursor=pointer]:
            - /url: /category/tom-jerry
          - link "Hero's" [ref=e11] [cursor=pointer]:
            - /url: /category/hero-s
          - link "Lamps" [ref=e13] [cursor=pointer]:
            - /url: /category/lamps
          - link "Key Ring" [ref=e15] [cursor=pointer]:
            - /url: /category/key-ring
          - link "Dogs" [ref=e17] [cursor=pointer]:
            - /url: /category/dogs
          - link "All Products" [ref=e18] [cursor=pointer]:
            - /url: /products
        - generic [ref=e19]:
          - img [ref=e20]
          - textbox "Search products..." [ref=e23]
        - generic [ref=e24]:
          - link [ref=e25] [cursor=pointer]:
            - /url: /search
            - img [ref=e26]
          - link [ref=e29] [cursor=pointer]:
            - /url: /wishlist
            - img [ref=e30]
          - link [ref=e32] [cursor=pointer]:
            - /url: /cart
            - img [ref=e33]
          - button "Sign in" [ref=e37]:
            - generic [ref=e38]:
              - img [ref=e39]
              - generic [ref=e42]: Sign in
    - main [ref=e43]:
      - generic [ref=e44]:
        - navigation [ref=e45]:
          - link "Home" [ref=e46] [cursor=pointer]:
            - /url: /
          - generic [ref=e47]: /
          - generic [ref=e48]: milk
        - generic [ref=e49]:
          - generic [ref=e51]: 📦
          - generic [ref=e52]:
            - heading "milk" [level=1] [ref=e53]
            - generic [ref=e54]:
              - generic [ref=e56]: $1,200.00
              - paragraph [ref=e57]: inclusive of all taxes
            - generic [ref=e59]: Out of Stock
            - button "Out of Stock" [disabled] [ref=e61]
            - generic [ref=e62]:
              - generic [ref=e63]:
                - img [ref=e64]
                - generic [ref=e69]: Free Delivery
              - generic [ref=e70]:
                - img [ref=e71]
                - generic [ref=e76]: Easy Returns
              - generic [ref=e77]:
                - img [ref=e78]
                - generic [ref=e80]: Secure Pay
        - generic [ref=e81]:
          - heading "Customer Reviews" [level=2] [ref=e83]
          - paragraph [ref=e84]: No reviews yet. Be the first!
    - contentinfo [ref=e85]:
      - generic [ref=e86]:
        - generic [ref=e87]:
          - heading "STORE" [level=2] [ref=e88]
          - paragraph [ref=e89]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e90]:
            - link "IG" [ref=e91] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e92] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e93] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e94]:
          - heading "Shop" [level=3] [ref=e95]
          - list [ref=e96]:
            - listitem [ref=e97]:
              - link "All Products" [ref=e98] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e99]:
              - link "Tom & Jerry" [ref=e100] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e101]:
              - link "Hero's" [ref=e102] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e103]:
              - link "Lamps" [ref=e104] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e105]:
              - link "Key Ring" [ref=e106] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e107]:
              - link "Dogs" [ref=e108] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e109]:
          - heading "Account" [level=3] [ref=e110]
          - list [ref=e111]:
            - listitem [ref=e112]:
              - link "My Orders" [ref=e113] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e114]:
              - link "Wishlist" [ref=e115] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e116]:
              - link "My Profile" [ref=e117] [cursor=pointer]:
                - /url: /account
        - generic [ref=e118]:
          - heading "Support" [level=3] [ref=e119]
          - list [ref=e120]:
            - listitem [ref=e121]:
              - link "Contact Us" [ref=e122] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e123]:
              - link "FAQs" [ref=e124] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e125]:
              - link "Refund & Returns" [ref=e126] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e127]:
              - link "Shipping Info" [ref=e128] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e129]:
          - heading "Legal" [level=3] [ref=e130]
          - list [ref=e131]:
            - listitem [ref=e132]:
              - link "Privacy Policy" [ref=e133] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e134]:
              - link "Terms of Service" [ref=e135] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e136]:
        - paragraph [ref=e137]: © 2026 Store. All rights reserved.
        - generic [ref=e138]:
          - link "orders@aitalk247.com" [ref=e139] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e140] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e142]:
      - img [ref=e143]
  - button "Open Next.js Dev Tools" [ref=e150] [cursor=pointer]:
    - img [ref=e151]
  - alert [ref=e154]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Auth flow', () => {
  4  |   test('login page loads correctly', async ({ page }) => {
  5  |     await page.goto('/login')
  6  |     await expect(page).toHaveTitle(/Login|Sign in/i)
  7  |     // Should have email input
  8  |     await expect(page.locator('input[type="email"]')).toBeVisible()
  9  |   })
  10 | 
  11 |   test('login shows error for invalid credentials', async ({ page }) => {
  12 |     await page.goto('/login')
  13 |     // Switch to email/password tab if needed
  14 |     const emailTab = page.locator('button', { hasText: /Email.*Password|Sign in with email/i })
  15 |     if (await emailTab.isVisible()) await emailTab.click()
  16 | 
  17 |     await page.locator('input[type="email"]').fill('invalid@test.com')
  18 |     await page.locator('input[type="password"]').fill('wrongpassword')
  19 |     await page.locator('button[type="submit"]').click()
  20 |     // Error message should appear
  21 |     await expect(page.locator('[role="alert"], .text-red-500, .text-red-600').first()).toBeVisible({ timeout: 5000 })
  22 |   })
  23 | 
  24 |   test('accessing protected route redirects to login', async ({ page }) => {
  25 |     await page.goto('/account')
  26 |     await expect(page).toHaveURL(/login/)
  27 |   })
  28 | 
  29 |   test('checkout redirect when not logged in', async ({ page }) => {
  30 |     // Set up some cart items in localStorage first
  31 |     await page.goto('/products')
  32 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  33 |     const href = await firstProduct.getAttribute('href')
  34 |     if (href) {
  35 |       await page.goto(href)
  36 |       const addBtn = page.locator('button', { hasText: /Add to Cart/i }).first()
> 37 |       if (await addBtn.isEnabled()) {
     |                        ^ Error: locator.isEnabled: Test timeout of 30000ms exceeded.
  38 |         await addBtn.click()
  39 |         await page.goto('/checkout')
  40 |         // Should either show checkout or redirect to login
  41 |         const url = page.url()
  42 |         const hasCheckout = url.includes('/checkout') || url.includes('/login')
  43 |         expect(hasCheckout).toBe(true)
  44 |       }
  45 |     }
  46 |   })
  47 | })
  48 | 
```