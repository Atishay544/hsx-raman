# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: homepage.spec.ts >> Homepage >> header search icon navigates to search
- Location: e2e\homepage.spec.ts:18:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('a[href="/search"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('a[href="/search"]').first()
    8 × locator resolved to <a href="/search" class="hidden md:flex p-2 text-gray-600 hover:text-black transition">…</a>
      - unexpected value "hidden"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - button [ref=e6]:
          - img [ref=e7]
        - link "STORE" [ref=e8] [cursor=pointer]:
          - /url: /
        - generic [ref=e9]:
          - link [ref=e10] [cursor=pointer]:
            - /url: /search
            - img [ref=e11]
          - link [ref=e14] [cursor=pointer]:
            - /url: /cart
            - img [ref=e15]
          - button [ref=e19]:
            - img [ref=e21]
    - main [ref=e24]:
      - generic [ref=e25]:
        - generic [ref=e26]:
          - link "banner" [ref=e28] [cursor=pointer]:
            - /url: /products
            - img "banner" [ref=e29]
          - link "banner" [ref=e31] [cursor=pointer]:
            - /url: /products
            - img "banner" [ref=e32]
          - button "Previous banner" [ref=e33]:
            - img [ref=e34]
          - button "Next banner" [ref=e36]:
            - img [ref=e37]
          - generic [ref=e39]:
            - button "Go to slide 1" [ref=e40]
            - button "Go to slide 2" [ref=e41]
        - generic [ref=e42]:
          - heading "Shop by Category" [level=2] [ref=e44]
          - generic [ref=e45]:
            - link "🏷️ Tom & Jerry" [ref=e47] [cursor=pointer]:
              - /url: /category/tom-jerry
              - generic [ref=e49]: 🏷️
              - generic [ref=e50]: Tom & Jerry
            - link "🏷️ Hero's" [ref=e52] [cursor=pointer]:
              - /url: /category/hero-s
              - generic [ref=e54]: 🏷️
              - generic [ref=e55]: Hero's
            - link "🏷️ Lamps" [ref=e57] [cursor=pointer]:
              - /url: /category/lamps
              - generic [ref=e59]: 🏷️
              - generic [ref=e60]: Lamps
            - link "🏷️ Key Ring" [ref=e62] [cursor=pointer]:
              - /url: /category/key-ring
              - generic [ref=e64]: 🏷️
              - generic [ref=e65]: Key Ring
            - link "🏷️ Dogs" [ref=e67] [cursor=pointer]:
              - /url: /category/dogs
              - generic [ref=e69]: 🏷️
              - generic [ref=e70]: Dogs
        - generic [ref=e71]:
          - generic [ref=e72]:
            - heading "Featured Products" [level=2] [ref=e73]
            - link "View all →" [ref=e74] [cursor=pointer]:
              - /url: /products
          - generic [ref=e75]:
            - link "📦 milk $1,200.00" [ref=e77] [cursor=pointer]:
              - /url: /products/milk
              - generic [ref=e79]: 📦
              - generic [ref=e80]:
                - paragraph [ref=e81]: milk
                - generic [ref=e83]: $1,200.00
            - link "I am Groot -17% I am Groot $150.00 $180.00" [ref=e85] [cursor=pointer]:
              - /url: /products/i-am-groot
              - generic [ref=e86]:
                - img "I am Groot" [ref=e87]
                - generic [ref=e88]: "-17%"
              - generic [ref=e89]:
                - paragraph [ref=e90]: I am Groot
                - generic [ref=e91]:
                  - generic [ref=e92]: $150.00
                  - generic [ref=e93]: $180.00
            - link "Tom & Jerry -33% Tom & Jerry $200.00 $300.00" [ref=e95] [cursor=pointer]:
              - /url: /products/tom-jerry
              - generic [ref=e96]:
                - img "Tom & Jerry" [ref=e97]
                - generic [ref=e98]: "-33%"
              - generic [ref=e99]:
                - paragraph [ref=e100]: Tom & Jerry
                - generic [ref=e101]:
                  - generic [ref=e102]: $200.00
                  - generic [ref=e103]: $300.00
            - link "key ring paws key ring paws $60.00 $60.00" [ref=e105] [cursor=pointer]:
              - /url: /products/key-ring-paws
              - img "key ring paws" [ref=e107]
              - generic [ref=e108]:
                - paragraph [ref=e109]: key ring paws
                - generic [ref=e110]:
                  - generic [ref=e111]: $60.00
                  - generic [ref=e112]: $60.00
            - link "lamp 2 -38% lamp 2 $50.00 $80.00" [ref=e114] [cursor=pointer]:
              - /url: /products/lamp-2
              - generic [ref=e115]:
                - img "lamp 2" [ref=e116]
                - generic [ref=e117]: "-38%"
              - generic [ref=e118]:
                - paragraph [ref=e119]: lamp 2
                - generic [ref=e120]:
                  - generic [ref=e121]: $50.00
                  - generic [ref=e122]: $80.00
            - link "lamp 1 -18% lamp 1 $99.00 $120.00" [ref=e124] [cursor=pointer]:
              - /url: /products/lamp-1
              - generic [ref=e125]:
                - img "lamp 1" [ref=e126]
                - generic [ref=e127]: "-18%"
              - generic [ref=e128]:
                - paragraph [ref=e129]: lamp 1
                - generic [ref=e130]:
                  - generic [ref=e131]: $99.00
                  - generic [ref=e132]: $120.00
        - generic [ref=e134]:
          - generic [ref=e135]:
            - paragraph [ref=e136]: Limited Time
            - heading "Up to 50% OFF" [level=2] [ref=e137]
            - paragraph [ref=e138]: Selected items — while stocks last
          - link "See Deals" [ref=e139] [cursor=pointer]:
            - /url: /products?sale=true
        - generic [ref=e140]:
          - generic [ref=e141]:
            - heading "Deals & Offers" [level=2] [ref=e142]
            - link "View all →" [ref=e143] [cursor=pointer]:
              - /url: /products?sale=true
          - generic [ref=e144]:
            - link "I am Groot -17% I am Groot $150.00 $180.00" [ref=e146] [cursor=pointer]:
              - /url: /products/i-am-groot
              - generic [ref=e147]:
                - img "I am Groot" [ref=e148]
                - generic [ref=e149]: "-17%"
              - generic [ref=e150]:
                - paragraph [ref=e151]: I am Groot
                - generic [ref=e152]:
                  - generic [ref=e153]: $150.00
                  - generic [ref=e154]: $180.00
            - link "Tom & Jerry -33% Tom & Jerry $200.00 $300.00" [ref=e156] [cursor=pointer]:
              - /url: /products/tom-jerry
              - generic [ref=e157]:
                - img "Tom & Jerry" [ref=e158]
                - generic [ref=e159]: "-33%"
              - generic [ref=e160]:
                - paragraph [ref=e161]: Tom & Jerry
                - generic [ref=e162]:
                  - generic [ref=e163]: $200.00
                  - generic [ref=e164]: $300.00
            - link "key ring paws key ring paws $60.00 $60.00" [ref=e166] [cursor=pointer]:
              - /url: /products/key-ring-paws
              - img "key ring paws" [ref=e168]
              - generic [ref=e169]:
                - paragraph [ref=e170]: key ring paws
                - generic [ref=e171]:
                  - generic [ref=e172]: $60.00
                  - generic [ref=e173]: $60.00
            - link "lamp 2 -38% lamp 2 $50.00 $80.00" [ref=e175] [cursor=pointer]:
              - /url: /products/lamp-2
              - generic [ref=e176]:
                - img "lamp 2" [ref=e177]
                - generic [ref=e178]: "-38%"
              - generic [ref=e179]:
                - paragraph [ref=e180]: lamp 2
                - generic [ref=e181]:
                  - generic [ref=e182]: $50.00
                  - generic [ref=e183]: $80.00
            - link "lamp 1 -18% lamp 1 $99.00 $120.00" [ref=e185] [cursor=pointer]:
              - /url: /products/lamp-1
              - generic [ref=e186]:
                - img "lamp 1" [ref=e187]
                - generic [ref=e188]: "-18%"
              - generic [ref=e189]:
                - paragraph [ref=e190]: lamp 1
                - generic [ref=e191]:
                  - generic [ref=e192]: $99.00
                  - generic [ref=e193]: $120.00
    - contentinfo [ref=e194]:
      - generic [ref=e195]:
        - generic [ref=e196]:
          - heading "STORE" [level=2] [ref=e197]
          - paragraph [ref=e198]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e199]:
            - link "IG" [ref=e200] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e201] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e202] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e203]:
          - heading "Shop" [level=3] [ref=e204]
          - list [ref=e205]:
            - listitem [ref=e206]:
              - link "All Products" [ref=e207] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e208]:
              - link "Tom & Jerry" [ref=e209] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e210]:
              - link "Hero's" [ref=e211] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e212]:
              - link "Lamps" [ref=e213] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e214]:
              - link "Key Ring" [ref=e215] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e216]:
              - link "Dogs" [ref=e217] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e218]:
          - heading "Account" [level=3] [ref=e219]
          - list [ref=e220]:
            - listitem [ref=e221]:
              - link "My Orders" [ref=e222] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e223]:
              - link "Wishlist" [ref=e224] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e225]:
              - link "My Profile" [ref=e226] [cursor=pointer]:
                - /url: /account
        - generic [ref=e227]:
          - heading "Support" [level=3] [ref=e228]
          - list [ref=e229]:
            - listitem [ref=e230]:
              - link "Contact Us" [ref=e231] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e232]:
              - link "FAQs" [ref=e233] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e234]:
              - link "Refund & Returns" [ref=e235] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e236]:
              - link "Shipping Info" [ref=e237] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e238]:
          - heading "Legal" [level=3] [ref=e239]
          - list [ref=e240]:
            - listitem [ref=e241]:
              - link "Privacy Policy" [ref=e242] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e243]:
              - link "Terms of Service" [ref=e244] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e245]:
        - paragraph [ref=e246]: © 2026 Store. All rights reserved.
        - generic [ref=e247]:
          - link "orders@aitalk247.com" [ref=e248] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e249] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e251]:
      - img [ref=e252]
  - button "Open Next.js Dev Tools" [ref=e259] [cursor=pointer]:
    - img [ref=e260]
  - alert [ref=e263]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Homepage', () => {
  4  |   test('loads and shows hero content', async ({ page }) => {
  5  |     await page.goto('/')
  6  |     await expect(page).toHaveTitle(/My Store/)
  7  |     // Header should be visible
  8  |     await expect(page.locator('header')).toBeVisible()
  9  |   })
  10 | 
  11 |   test('navigation links work', async ({ page }) => {
  12 |     await page.goto('/')
  13 |     // Shop/Products link
  14 |     const productsLink = page.getByRole('link', { name: /products|shop/i }).first()
  15 |     await expect(productsLink).toBeVisible()
  16 |   })
  17 | 
  18 |   test('header search icon navigates to search', async ({ page }) => {
  19 |     await page.goto('/')
  20 |     // Click search icon in header
  21 |     const searchLink = page.locator('a[href="/search"]').first()
> 22 |     await expect(searchLink).toBeVisible()
     |                              ^ Error: expect(locator).toBeVisible() failed
  23 |     await searchLink.click()
  24 |     await expect(page).toHaveURL('/search')
  25 |   })
  26 | 
  27 |   test('cart icon is visible in header', async ({ page }) => {
  28 |     await page.goto('/')
  29 |     const cartLink = page.locator('a[href="/cart"]').first()
  30 |     await expect(cartLink).toBeVisible()
  31 |   })
  32 | })
  33 | 
```