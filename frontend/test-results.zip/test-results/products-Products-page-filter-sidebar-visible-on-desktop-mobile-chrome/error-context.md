# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: products.spec.ts >> Products page >> filter sidebar visible on desktop
- Location: e2e\products.spec.ts:16:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('aside')
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('aside')
    9 × locator resolved to <aside class="hidden lg:block w-56 shrink-0">…</aside>
      - unexpected value "hidden"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - button [ref=e6]:
          - img [ref=e7]
        - link "STORE" [ref=e8] [cursor=pointer]:
          - /url: /
        - generic [ref=e9]:
          - link [ref=e10] [cursor=pointer]:
            - /url: /search
            - img [ref=e11]
          - link [ref=e14] [cursor=pointer]:
            - /url: /cart
            - img [ref=e15]
          - button [ref=e19]:
            - img [ref=e21]
    - main [ref=e24]:
      - generic [ref=e25]:
        - heading "All Products" [level=1] [ref=e26]
        - generic [ref=e28]:
          - generic [ref=e29]:
            - paragraph [ref=e30]: 6 products
            - generic [ref=e31]:
              - generic [ref=e32]: "Sort:"
              - combobox [ref=e33]:
                - option "Newest" [selected]
                - option "Popular"
                - 'option "Price: Low to High"'
                - 'option "Price: High to Low"'
          - generic [ref=e34]:
            - link "📦 milk $1,200.00" [ref=e35] [cursor=pointer]:
              - /url: /products/milk
              - generic [ref=e37]: 📦
              - paragraph [ref=e38]: milk
              - generic [ref=e40]: $1,200.00
            - link "I am Groot -17% I am Groot $150.00 $180.00" [ref=e41] [cursor=pointer]:
              - /url: /products/i-am-groot
              - generic [ref=e42]:
                - img "I am Groot" [ref=e43]
                - generic [ref=e44]: "-17%"
              - paragraph [ref=e45]: I am Groot
              - generic [ref=e46]:
                - generic [ref=e47]: $150.00
                - generic [ref=e48]: $180.00
            - link "Tom & Jerry -33% Tom & Jerry $200.00 $300.00" [ref=e49] [cursor=pointer]:
              - /url: /products/tom-jerry
              - generic [ref=e50]:
                - img "Tom & Jerry" [ref=e51]
                - generic [ref=e52]: "-33%"
              - paragraph [ref=e53]: Tom & Jerry
              - generic [ref=e54]:
                - generic [ref=e55]: $200.00
                - generic [ref=e56]: $300.00
            - link "key ring paws key ring paws $60.00 $60.00" [ref=e57] [cursor=pointer]:
              - /url: /products/key-ring-paws
              - img "key ring paws" [ref=e59]
              - paragraph [ref=e60]: key ring paws
              - generic [ref=e61]:
                - generic [ref=e62]: $60.00
                - generic [ref=e63]: $60.00
            - link "lamp 2 -38% lamp 2 $50.00 $80.00" [ref=e64] [cursor=pointer]:
              - /url: /products/lamp-2
              - generic [ref=e65]:
                - img "lamp 2" [ref=e66]
                - generic [ref=e67]: "-38%"
              - paragraph [ref=e68]: lamp 2
              - generic [ref=e69]:
                - generic [ref=e70]: $50.00
                - generic [ref=e71]: $80.00
            - link "lamp 1 -18% lamp 1 $99.00 $120.00" [ref=e72] [cursor=pointer]:
              - /url: /products/lamp-1
              - generic [ref=e73]:
                - img "lamp 1" [ref=e74]
                - generic [ref=e75]: "-18%"
              - paragraph [ref=e76]: lamp 1
              - generic [ref=e77]:
                - generic [ref=e78]: $99.00
                - generic [ref=e79]: $120.00
    - contentinfo [ref=e80]:
      - generic [ref=e81]:
        - generic [ref=e82]:
          - heading "STORE" [level=2] [ref=e83]
          - paragraph [ref=e84]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e85]:
            - link "IG" [ref=e86] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e87] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e88] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e89]:
          - heading "Shop" [level=3] [ref=e90]
          - list [ref=e91]:
            - listitem [ref=e92]:
              - link "All Products" [ref=e93] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e94]:
              - link "Tom & Jerry" [ref=e95] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e96]:
              - link "Hero's" [ref=e97] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e98]:
              - link "Lamps" [ref=e99] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e100]:
              - link "Key Ring" [ref=e101] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e102]:
              - link "Dogs" [ref=e103] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e104]:
          - heading "Account" [level=3] [ref=e105]
          - list [ref=e106]:
            - listitem [ref=e107]:
              - link "My Orders" [ref=e108] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e109]:
              - link "Wishlist" [ref=e110] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e111]:
              - link "My Profile" [ref=e112] [cursor=pointer]:
                - /url: /account
        - generic [ref=e113]:
          - heading "Support" [level=3] [ref=e114]
          - list [ref=e115]:
            - listitem [ref=e116]:
              - link "Contact Us" [ref=e117] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e118]:
              - link "FAQs" [ref=e119] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e120]:
              - link "Refund & Returns" [ref=e121] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e122]:
              - link "Shipping Info" [ref=e123] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e124]:
          - heading "Legal" [level=3] [ref=e125]
          - list [ref=e126]:
            - listitem [ref=e127]:
              - link "Privacy Policy" [ref=e128] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e129]:
              - link "Terms of Service" [ref=e130] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e131]:
        - paragraph [ref=e132]: © 2026 Store. All rights reserved.
        - generic [ref=e133]:
          - link "orders@aitalk247.com" [ref=e134] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e135] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e137]:
      - img [ref=e138]
  - button "Open Next.js Dev Tools" [ref=e145] [cursor=pointer]:
    - img [ref=e146]
  - alert [ref=e149]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Products page', () => {
  4  |   test('loads product listing', async ({ page }) => {
  5  |     await page.goto('/products')
  6  |     await expect(page).toHaveTitle(/All Products/)
  7  |     // Product count should show
  8  |     await expect(page.locator('text=/\\d+ products/')).toBeVisible()
  9  |   })
  10 | 
  11 |   test('sort selector is visible', async ({ page }) => {
  12 |     await page.goto('/products')
  13 |     await expect(page.locator('select')).toBeVisible()
  14 |   })
  15 | 
  16 |   test('filter sidebar visible on desktop', async ({ page }) => {
  17 |     await page.goto('/products')
> 18 |     await expect(page.locator('aside')).toBeVisible()
     |                                         ^ Error: expect(locator).toBeVisible() failed
  19 |   })
  20 | 
  21 |   test('clicking a product navigates to detail page', async ({ page }) => {
  22 |     await page.goto('/products')
  23 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  24 |     const href = await firstProduct.getAttribute('href')
  25 |     if (href) {
  26 |       await firstProduct.click()
  27 |       await expect(page).toHaveURL(href)
  28 |       await expect(page.locator('h1')).toBeVisible()
  29 |     }
  30 |   })
  31 | 
  32 |   test('price sort ascending works', async ({ page }) => {
  33 |     await page.goto('/products')
  34 |     await page.selectOption('select', 'price_asc')
  35 |     await expect(page).toHaveURL(/sort=price_asc/)
  36 |   })
  37 | })
  38 | 
```