# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: cart.spec.ts >> Add to cart flow >> adding item to cart updates cart count
- Location: e2e\cart.spec.ts:43:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.isEnabled: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('button').filter({ hasText: /Add to Cart/i }).first()

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - link "STORE" [ref=e6] [cursor=pointer]:
          - /url: /
        - navigation [ref=e7]:
          - link "Tom & Jerry" [ref=e9] [cursor=pointer]:
            - /url: /category/tom-jerry
          - link "Hero's" [ref=e11] [cursor=pointer]:
            - /url: /category/hero-s
          - link "Lamps" [ref=e13] [cursor=pointer]:
            - /url: /category/lamps
          - link "Key Ring" [ref=e15] [cursor=pointer]:
            - /url: /category/key-ring
          - link "Dogs" [ref=e17] [cursor=pointer]:
            - /url: /category/dogs
          - link "All Products" [ref=e18] [cursor=pointer]:
            - /url: /products
        - generic [ref=e19]:
          - img [ref=e20]
          - textbox "Search products..." [ref=e23]
        - generic [ref=e24]:
          - link [ref=e25] [cursor=pointer]:
            - /url: /search
            - img [ref=e26]
          - link [ref=e29] [cursor=pointer]:
            - /url: /wishlist
            - img [ref=e30]
          - link [ref=e32] [cursor=pointer]:
            - /url: /cart
            - img [ref=e33]
          - button "Sign in" [ref=e37]:
            - generic [ref=e38]:
              - img [ref=e39]
              - generic [ref=e42]: Sign in
    - main [ref=e43]:
      - generic [ref=e44]:
        - navigation [ref=e45]:
          - link "Home" [ref=e46] [cursor=pointer]:
            - /url: /
          - generic [ref=e47]: /
          - generic [ref=e48]: milk
        - generic [ref=e49]:
          - generic [ref=e51]: 📦
          - generic [ref=e52]:
            - heading "milk" [level=1] [ref=e53]
            - generic [ref=e54]:
              - generic [ref=e56]: $1,200.00
              - paragraph [ref=e57]: inclusive of all taxes
            - generic [ref=e59]: Out of Stock
            - button "Out of Stock" [disabled] [ref=e61]
            - generic [ref=e62]:
              - generic [ref=e63]:
                - img [ref=e64]
                - generic [ref=e69]: Free Delivery
              - generic [ref=e70]:
                - img [ref=e71]
                - generic [ref=e76]: Easy Returns
              - generic [ref=e77]:
                - img [ref=e78]
                - generic [ref=e80]: Secure Pay
        - generic [ref=e81]:
          - heading "Customer Reviews" [level=2] [ref=e83]
          - paragraph [ref=e84]: No reviews yet. Be the first!
    - contentinfo [ref=e85]:
      - generic [ref=e86]:
        - generic [ref=e87]:
          - heading "STORE" [level=2] [ref=e88]
          - paragraph [ref=e89]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e90]:
            - link "IG" [ref=e91] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e92] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e93] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e94]:
          - heading "Shop" [level=3] [ref=e95]
          - list [ref=e96]:
            - listitem [ref=e97]:
              - link "All Products" [ref=e98] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e99]:
              - link "Tom & Jerry" [ref=e100] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e101]:
              - link "Hero's" [ref=e102] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e103]:
              - link "Lamps" [ref=e104] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e105]:
              - link "Key Ring" [ref=e106] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e107]:
              - link "Dogs" [ref=e108] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e109]:
          - heading "Account" [level=3] [ref=e110]
          - list [ref=e111]:
            - listitem [ref=e112]:
              - link "My Orders" [ref=e113] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e114]:
              - link "Wishlist" [ref=e115] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e116]:
              - link "My Profile" [ref=e117] [cursor=pointer]:
                - /url: /account
        - generic [ref=e118]:
          - heading "Support" [level=3] [ref=e119]
          - list [ref=e120]:
            - listitem [ref=e121]:
              - link "Contact Us" [ref=e122] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e123]:
              - link "FAQs" [ref=e124] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e125]:
              - link "Refund & Returns" [ref=e126] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e127]:
              - link "Shipping Info" [ref=e128] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e129]:
          - heading "Legal" [level=3] [ref=e130]
          - list [ref=e131]:
            - listitem [ref=e132]:
              - link "Privacy Policy" [ref=e133] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e134]:
              - link "Terms of Service" [ref=e135] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e136]:
        - paragraph [ref=e137]: © 2026 Store. All rights reserved.
        - generic [ref=e138]:
          - link "orders@aitalk247.com" [ref=e139] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e140] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e142]:
      - img [ref=e143]
  - button "Open Next.js Dev Tools" [ref=e150] [cursor=pointer]:
    - img [ref=e151]
  - alert [ref=e154]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Cart page', () => {
  4  |   test('shows empty state when cart is empty', async ({ page }) => {
  5  |     // Clear localStorage cart before visiting
  6  |     await page.goto('/cart')
  7  |     // If cart store has no items (fresh browser), shows empty state
  8  |     const body = await page.content()
  9  |     if (body.includes('Your cart is empty')) {
  10 |       await expect(page.locator('text=Your cart is empty')).toBeVisible()
  11 |       await expect(page.getByRole('link', { name: /Shop Now/i })).toBeVisible()
  12 |     }
  13 |   })
  14 | 
  15 |   test('cart page has correct title', async ({ page }) => {
  16 |     await page.goto('/cart')
  17 |     await expect(page).toHaveTitle(/My Store/)
  18 |   })
  19 | 
  20 |   test('empty cart shop now link goes to products', async ({ page }) => {
  21 |     await page.goto('/cart')
  22 |     const shopLink = page.getByRole('link', { name: /Shop Now/i })
  23 |     if (await shopLink.isVisible()) {
  24 |       await shopLink.click()
  25 |       await expect(page).toHaveURL('/products')
  26 |     }
  27 |   })
  28 | })
  29 | 
  30 | test.describe('Add to cart flow', () => {
  31 |   test('add to cart button visible on product page', async ({ page }) => {
  32 |     await page.goto('/products')
  33 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  34 |     const href = await firstProduct.getAttribute('href')
  35 |     if (href) {
  36 |       await page.goto(href)
  37 |       // Add to cart button should be visible
  38 |       const addBtn = page.locator('button', { hasText: /Add to Cart|Out of Stock/i }).first()
  39 |       await expect(addBtn).toBeVisible()
  40 |     }
  41 |   })
  42 | 
  43 |   test('adding item to cart updates cart count', async ({ page }) => {
  44 |     await page.goto('/products')
  45 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  46 |     const href = await firstProduct.getAttribute('href')
  47 |     if (href) {
  48 |       await page.goto(href)
  49 |       const addBtn = page.locator('button', { hasText: /Add to Cart/i }).first()
> 50 |       if (await addBtn.isEnabled()) {
     |                        ^ Error: locator.isEnabled: Test timeout of 30000ms exceeded.
  51 |         await addBtn.click()
  52 |         // Cart count in header should update
  53 |         await page.goto('/cart')
  54 |         await expect(page.locator('text=/Cart \\(/i')).toBeVisible()
  55 |       }
  56 |     }
  57 |   })
  58 | })
  59 | 
```