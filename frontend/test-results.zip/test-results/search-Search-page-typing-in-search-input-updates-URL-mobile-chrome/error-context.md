# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: search.spec.ts >> Search page >> typing in search input updates URL
- Location: e2e\search.spec.ts:24:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.fill: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('input').first()
    - locator resolved to <input value="" type="text" placeholder="Search products..." class="flex-1 text-sm outline-none bg-transparent text-gray-700 placeholder-gray-400"/>
    - fill("laptop")
  - attempting fill action
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
      - waiting 100ms
    58 × waiting for element to be visible, enabled and editable
       - element is not visible
     - retrying fill action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - button [ref=e6]:
          - img [ref=e7]
        - link "STORE" [ref=e8] [cursor=pointer]:
          - /url: /
        - generic [ref=e9]:
          - link [ref=e10] [cursor=pointer]:
            - /url: /search
            - img [ref=e11]
          - link [ref=e14] [cursor=pointer]:
            - /url: /cart
            - img [ref=e15]
          - button [ref=e19]:
            - img [ref=e21]
    - main [ref=e24]:
      - generic [ref=e25]:
        - generic [ref=e27]:
          - img [ref=e28]
          - textbox "Search products, categories…" [active] [ref=e31]
          - button "Search" [ref=e32]
        - generic [ref=e33]:
          - img [ref=e34]
          - paragraph [ref=e37]: Start typing to search products…
    - contentinfo [ref=e38]:
      - generic [ref=e39]:
        - generic [ref=e40]:
          - heading "STORE" [level=2] [ref=e41]
          - paragraph [ref=e42]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e43]:
            - link "IG" [ref=e44] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e45] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e46] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e47]:
          - heading "Shop" [level=3] [ref=e48]
          - list [ref=e49]:
            - listitem [ref=e50]:
              - link "All Products" [ref=e51] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e52]:
              - link "Tom & Jerry" [ref=e53] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e54]:
              - link "Hero's" [ref=e55] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e56]:
              - link "Lamps" [ref=e57] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e58]:
              - link "Key Ring" [ref=e59] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e60]:
              - link "Dogs" [ref=e61] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e62]:
          - heading "Account" [level=3] [ref=e63]
          - list [ref=e64]:
            - listitem [ref=e65]:
              - link "My Orders" [ref=e66] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e67]:
              - link "Wishlist" [ref=e68] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e69]:
              - link "My Profile" [ref=e70] [cursor=pointer]:
                - /url: /account
        - generic [ref=e71]:
          - heading "Support" [level=3] [ref=e72]
          - list [ref=e73]:
            - listitem [ref=e74]:
              - link "Contact Us" [ref=e75] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e76]:
              - link "FAQs" [ref=e77] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e78]:
              - link "Refund & Returns" [ref=e79] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e80]:
              - link "Shipping Info" [ref=e81] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e82]:
          - heading "Legal" [level=3] [ref=e83]
          - list [ref=e84]:
            - listitem [ref=e85]:
              - link "Privacy Policy" [ref=e86] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e87]:
              - link "Terms of Service" [ref=e88] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e89]:
        - paragraph [ref=e90]: © 2026 Store. All rights reserved.
        - generic [ref=e91]:
          - link "orders@aitalk247.com" [ref=e92] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e93] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e95]:
      - img [ref=e96]
  - button "Open Next.js Dev Tools" [ref=e103] [cursor=pointer]:
    - img [ref=e104]
  - alert [ref=e107]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Search page', () => {
  4  |   test('shows empty state when no query', async ({ page }) => {
  5  |     await page.goto('/search')
  6  |     await expect(page).toHaveTitle(/Search/)
  7  |     await expect(page.locator('text=Start typing to search')).toBeVisible()
  8  |   })
  9  | 
  10 |   test('shows results for a query', async ({ page }) => {
  11 |     await page.goto('/search?q=shirt')
  12 |     await expect(page).toHaveTitle(/Search: shirt/)
  13 |     // Either results or "no results" message
  14 |     const hasResults = await page.locator('text=/Products|No results/').isVisible()
  15 |     expect(hasResults).toBe(true)
  16 |   })
  17 | 
  18 |   test('search input has correct default value from URL', async ({ page }) => {
  19 |     await page.goto('/search?q=test')
  20 |     const input = page.locator('input[type="search"], input[placeholder*="Search"]').first()
  21 |     await expect(input).toHaveValue('test')
  22 |   })
  23 | 
  24 |   test('typing in search input updates URL', async ({ page }) => {
  25 |     await page.goto('/search')
  26 |     const input = page.locator('input').first()
> 27 |     await input.fill('laptop')
     |                 ^ Error: locator.fill: Test timeout of 30000ms exceeded.
  28 |     // Wait for debounce / form submit
  29 |     await page.keyboard.press('Enter')
  30 |     await expect(page).toHaveURL(/q=laptop/)
  31 |   })
  32 | })
  33 | 
```