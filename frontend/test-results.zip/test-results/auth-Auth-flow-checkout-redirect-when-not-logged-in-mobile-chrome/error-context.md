# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth.spec.ts >> Auth flow >> checkout redirect when not logged in
- Location: e2e\auth.spec.ts:29:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.isEnabled: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('button').filter({ hasText: /Add to Cart/i }).first()

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - button [ref=e6]:
          - img [ref=e7]
        - link "STORE" [ref=e8] [cursor=pointer]:
          - /url: /
        - generic [ref=e9]:
          - link [ref=e10] [cursor=pointer]:
            - /url: /search
            - img [ref=e11]
          - link [ref=e14] [cursor=pointer]:
            - /url: /cart
            - img [ref=e15]
          - button [ref=e19]:
            - img [ref=e21]
    - main [ref=e24]:
      - generic [ref=e25]:
        - navigation [ref=e26]:
          - link "Home" [ref=e27] [cursor=pointer]:
            - /url: /
          - generic [ref=e28]: /
          - generic [ref=e29]: milk
        - generic [ref=e30]:
          - generic [ref=e32]: 📦
          - generic [ref=e33]:
            - heading "milk" [level=1] [ref=e34]
            - generic [ref=e35]:
              - generic [ref=e37]: $1,200.00
              - paragraph [ref=e38]: inclusive of all taxes
            - generic [ref=e40]: Out of Stock
            - button "Out of Stock" [disabled] [ref=e42]
            - generic [ref=e43]:
              - generic [ref=e44]:
                - img [ref=e45]
                - generic [ref=e50]: Free Delivery
              - generic [ref=e51]:
                - img [ref=e52]
                - generic [ref=e57]: Easy Returns
              - generic [ref=e58]:
                - img [ref=e59]
                - generic [ref=e61]: Secure Pay
        - generic [ref=e62]:
          - heading "Customer Reviews" [level=2] [ref=e64]
          - paragraph [ref=e65]: No reviews yet. Be the first!
    - contentinfo [ref=e66]:
      - generic [ref=e67]:
        - generic [ref=e68]:
          - heading "STORE" [level=2] [ref=e69]
          - paragraph [ref=e70]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e71]:
            - link "IG" [ref=e72] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e73] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e74] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e75]:
          - heading "Shop" [level=3] [ref=e76]
          - list [ref=e77]:
            - listitem [ref=e78]:
              - link "All Products" [ref=e79] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e80]:
              - link "Tom & Jerry" [ref=e81] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e82]:
              - link "Hero's" [ref=e83] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e84]:
              - link "Lamps" [ref=e85] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e86]:
              - link "Key Ring" [ref=e87] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e88]:
              - link "Dogs" [ref=e89] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e90]:
          - heading "Account" [level=3] [ref=e91]
          - list [ref=e92]:
            - listitem [ref=e93]:
              - link "My Orders" [ref=e94] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e95]:
              - link "Wishlist" [ref=e96] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e97]:
              - link "My Profile" [ref=e98] [cursor=pointer]:
                - /url: /account
        - generic [ref=e99]:
          - heading "Support" [level=3] [ref=e100]
          - list [ref=e101]:
            - listitem [ref=e102]:
              - link "Contact Us" [ref=e103] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e104]:
              - link "FAQs" [ref=e105] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e106]:
              - link "Refund & Returns" [ref=e107] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e108]:
              - link "Shipping Info" [ref=e109] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e110]:
          - heading "Legal" [level=3] [ref=e111]
          - list [ref=e112]:
            - listitem [ref=e113]:
              - link "Privacy Policy" [ref=e114] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e115]:
              - link "Terms of Service" [ref=e116] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e117]:
        - paragraph [ref=e118]: © 2026 Store. All rights reserved.
        - generic [ref=e119]:
          - link "orders@aitalk247.com" [ref=e120] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e121] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e123]:
      - img [ref=e124]
  - button "Open Next.js Dev Tools" [ref=e131] [cursor=pointer]:
    - img [ref=e132]
  - alert [ref=e135]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Auth flow', () => {
  4  |   test('login page loads correctly', async ({ page }) => {
  5  |     await page.goto('/login')
  6  |     await expect(page).toHaveTitle(/Login|Sign in/i)
  7  |     // Should have email input
  8  |     await expect(page.locator('input[type="email"]')).toBeVisible()
  9  |   })
  10 | 
  11 |   test('login shows error for invalid credentials', async ({ page }) => {
  12 |     await page.goto('/login')
  13 |     // Switch to email/password tab if needed
  14 |     const emailTab = page.locator('button', { hasText: /Email.*Password|Sign in with email/i })
  15 |     if (await emailTab.isVisible()) await emailTab.click()
  16 | 
  17 |     await page.locator('input[type="email"]').fill('invalid@test.com')
  18 |     await page.locator('input[type="password"]').fill('wrongpassword')
  19 |     await page.locator('button[type="submit"]').click()
  20 |     // Error message should appear
  21 |     await expect(page.locator('[role="alert"], .text-red-500, .text-red-600').first()).toBeVisible({ timeout: 5000 })
  22 |   })
  23 | 
  24 |   test('accessing protected route redirects to login', async ({ page }) => {
  25 |     await page.goto('/account')
  26 |     await expect(page).toHaveURL(/login/)
  27 |   })
  28 | 
  29 |   test('checkout redirect when not logged in', async ({ page }) => {
  30 |     // Set up some cart items in localStorage first
  31 |     await page.goto('/products')
  32 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  33 |     const href = await firstProduct.getAttribute('href')
  34 |     if (href) {
  35 |       await page.goto(href)
  36 |       const addBtn = page.locator('button', { hasText: /Add to Cart/i }).first()
> 37 |       if (await addBtn.isEnabled()) {
     |                        ^ Error: locator.isEnabled: Test timeout of 30000ms exceeded.
  38 |         await addBtn.click()
  39 |         await page.goto('/checkout')
  40 |         // Should either show checkout or redirect to login
  41 |         const url = page.url()
  42 |         const hasCheckout = url.includes('/checkout') || url.includes('/login')
  43 |         expect(hasCheckout).toBe(true)
  44 |       }
  45 |     }
  46 |   })
  47 | })
  48 | 
```