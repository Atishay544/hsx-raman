# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: search.spec.ts >> Search page >> search input has correct default value from URL
- Location: e2e\search.spec.ts:18:7

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  locator('input[type="search"], input[placeholder*="Search"]').first()
Expected: "test"
Received: ""
Timeout:  5000ms

Call log:
  - Expect "toHaveValue" with timeout 5000ms
  - waiting for locator('input[type="search"], input[placeholder*="Search"]').first()
    8 × locator resolved to <input value="" type="text" placeholder="Search products..." class="flex-1 text-sm outline-none bg-transparent text-gray-700 placeholder-gray-400"/>
      - unexpected value ""

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - link "STORE" [ref=e6] [cursor=pointer]:
          - /url: /
        - navigation [ref=e7]:
          - link "Tom & Jerry" [ref=e9] [cursor=pointer]:
            - /url: /category/tom-jerry
          - link "Hero's" [ref=e11] [cursor=pointer]:
            - /url: /category/hero-s
          - link "Lamps" [ref=e13] [cursor=pointer]:
            - /url: /category/lamps
          - link "Key Ring" [ref=e15] [cursor=pointer]:
            - /url: /category/key-ring
          - link "Dogs" [ref=e17] [cursor=pointer]:
            - /url: /category/dogs
          - link "All Products" [ref=e18] [cursor=pointer]:
            - /url: /products
        - generic [ref=e19]:
          - img [ref=e20]
          - textbox "Search products..." [ref=e23]
        - generic [ref=e24]:
          - link [ref=e25] [cursor=pointer]:
            - /url: /search
            - img [ref=e26]
          - link [ref=e29] [cursor=pointer]:
            - /url: /wishlist
            - img [ref=e30]
          - link [ref=e32] [cursor=pointer]:
            - /url: /cart
            - img [ref=e33]
          - button "Sign in" [ref=e37]:
            - generic [ref=e38]:
              - img [ref=e39]
              - generic [ref=e42]: Sign in
    - main [ref=e43]:
      - generic [ref=e44]:
        - generic [ref=e46]:
          - img [ref=e47]
          - textbox "Search products, categories…" [active] [ref=e50]: test
          - button "Search" [ref=e51]
        - generic [ref=e52]:
          - paragraph [ref=e53]: No results for "test"
          - link "Browse all products" [ref=e54] [cursor=pointer]:
            - /url: /products
    - contentinfo [ref=e55]:
      - generic [ref=e56]:
        - generic [ref=e57]:
          - heading "STORE" [level=2] [ref=e58]
          - paragraph [ref=e59]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e60]:
            - link "IG" [ref=e61] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e62] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e63] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e64]:
          - heading "Shop" [level=3] [ref=e65]
          - list [ref=e66]:
            - listitem [ref=e67]:
              - link "All Products" [ref=e68] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e69]:
              - link "Tom & Jerry" [ref=e70] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e71]:
              - link "Hero's" [ref=e72] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e73]:
              - link "Lamps" [ref=e74] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e75]:
              - link "Key Ring" [ref=e76] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e77]:
              - link "Dogs" [ref=e78] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e79]:
          - heading "Account" [level=3] [ref=e80]
          - list [ref=e81]:
            - listitem [ref=e82]:
              - link "My Orders" [ref=e83] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e84]:
              - link "Wishlist" [ref=e85] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e86]:
              - link "My Profile" [ref=e87] [cursor=pointer]:
                - /url: /account
        - generic [ref=e88]:
          - heading "Support" [level=3] [ref=e89]
          - list [ref=e90]:
            - listitem [ref=e91]:
              - link "Contact Us" [ref=e92] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e93]:
              - link "FAQs" [ref=e94] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e95]:
              - link "Refund & Returns" [ref=e96] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e97]:
              - link "Shipping Info" [ref=e98] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e99]:
          - heading "Legal" [level=3] [ref=e100]
          - list [ref=e101]:
            - listitem [ref=e102]:
              - link "Privacy Policy" [ref=e103] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e104]:
              - link "Terms of Service" [ref=e105] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e106]:
        - paragraph [ref=e107]: © 2026 Store. All rights reserved.
        - generic [ref=e108]:
          - link "orders@aitalk247.com" [ref=e109] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e110] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e112]:
      - img [ref=e113]
  - button "Open Next.js Dev Tools" [ref=e120] [cursor=pointer]:
    - img [ref=e121]
  - alert [ref=e124]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Search page', () => {
  4  |   test('shows empty state when no query', async ({ page }) => {
  5  |     await page.goto('/search')
  6  |     await expect(page).toHaveTitle(/Search/)
  7  |     await expect(page.locator('text=Start typing to search')).toBeVisible()
  8  |   })
  9  | 
  10 |   test('shows results for a query', async ({ page }) => {
  11 |     await page.goto('/search?q=shirt')
  12 |     await expect(page).toHaveTitle(/Search: shirt/)
  13 |     // Either results or "no results" message
  14 |     const hasResults = await page.locator('text=/Products|No results/').isVisible()
  15 |     expect(hasResults).toBe(true)
  16 |   })
  17 | 
  18 |   test('search input has correct default value from URL', async ({ page }) => {
  19 |     await page.goto('/search?q=test')
  20 |     const input = page.locator('input[type="search"], input[placeholder*="Search"]').first()
> 21 |     await expect(input).toHaveValue('test')
     |                         ^ Error: expect(locator).toHaveValue(expected) failed
  22 |   })
  23 | 
  24 |   test('typing in search input updates URL', async ({ page }) => {
  25 |     await page.goto('/search')
  26 |     const input = page.locator('input').first()
  27 |     await input.fill('laptop')
  28 |     // Wait for debounce / form submit
  29 |     await page.keyboard.press('Enter')
  30 |     await expect(page).toHaveURL(/q=laptop/)
  31 |   })
  32 | })
  33 | 
```