# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mobile.spec.ts >> Mobile layout >> products page hides sidebar filter on mobile
- Location: e2e\mobile.spec.ts:12:7

# Error details

```
Error: expect(locator).toBeHidden() failed

Locator:  locator('aside')
Expected: hidden
Received: visible
Timeout:  5000ms

Call log:
  - Expect "toBeHidden" with timeout 5000ms
  - waiting for locator('aside')
    9 × locator resolved to <aside class="hidden lg:block w-56 shrink-0">…</aside>
      - unexpected value "visible"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - link "STORE" [ref=e6] [cursor=pointer]:
          - /url: /
        - navigation [ref=e7]:
          - link "Tom & Jerry" [ref=e9] [cursor=pointer]:
            - /url: /category/tom-jerry
          - link "Hero's" [ref=e11] [cursor=pointer]:
            - /url: /category/hero-s
          - link "Lamps" [ref=e13] [cursor=pointer]:
            - /url: /category/lamps
          - link "Key Ring" [ref=e15] [cursor=pointer]:
            - /url: /category/key-ring
          - link "Dogs" [ref=e17] [cursor=pointer]:
            - /url: /category/dogs
          - link "All Products" [ref=e18] [cursor=pointer]:
            - /url: /products
            - text: All Products
        - generic [ref=e20]:
          - img [ref=e21]
          - textbox "Search products..." [ref=e24]
        - generic [ref=e25]:
          - link [ref=e26] [cursor=pointer]:
            - /url: /search
            - img [ref=e27]
          - link [ref=e30] [cursor=pointer]:
            - /url: /wishlist
            - img [ref=e31]
          - link [ref=e33] [cursor=pointer]:
            - /url: /cart
            - img [ref=e34]
          - button "Sign in" [ref=e38]:
            - generic [ref=e39]:
              - img [ref=e40]
              - generic [ref=e43]: Sign in
    - main [ref=e44]:
      - generic [ref=e45]:
        - heading "All Products" [level=1] [ref=e46]
        - generic [ref=e47]:
          - complementary [ref=e48]:
            - generic [ref=e49]:
              - generic [ref=e50]:
                - heading "Category" [level=3] [ref=e51]
                - list [ref=e52]:
                  - listitem [ref=e53]:
                    - button "All" [ref=e54]
                  - listitem [ref=e55]:
                    - button "Tom & Jerry" [ref=e56]
                  - listitem [ref=e57]:
                    - button "Hero's" [ref=e58]
                  - listitem [ref=e59]:
                    - button "Lamps" [ref=e60]
                  - listitem [ref=e61]:
                    - button "Key Ring" [ref=e62]
                  - listitem [ref=e63]:
                    - button "Dogs" [ref=e64]
              - generic [ref=e65]:
                - heading "Price Range" [level=3] [ref=e66]
                - generic [ref=e67]:
                  - spinbutton [ref=e68]
                  - generic [ref=e69]: –
                  - spinbutton [ref=e70]
              - generic [ref=e72] [cursor=pointer]:
                - checkbox "On Sale" [ref=e73]
                - generic [ref=e74]: On Sale
          - generic [ref=e75]:
            - generic [ref=e76]:
              - paragraph [ref=e77]: 6 products
              - generic [ref=e78]:
                - generic [ref=e79]: "Sort:"
                - combobox [ref=e80]:
                  - option "Newest" [selected]
                  - option "Popular"
                  - 'option "Price: Low to High"'
                  - 'option "Price: High to Low"'
            - generic [ref=e81]:
              - link "📦 milk $1,200.00" [ref=e82] [cursor=pointer]:
                - /url: /products/milk
                - generic [ref=e84]: 📦
                - paragraph [ref=e85]: milk
                - generic [ref=e87]: $1,200.00
              - link "I am Groot -17% I am Groot $150.00 $180.00" [ref=e88] [cursor=pointer]:
                - /url: /products/i-am-groot
                - generic [ref=e89]:
                  - img "I am Groot" [ref=e90]
                  - generic [ref=e91]: "-17%"
                - paragraph [ref=e92]: I am Groot
                - generic [ref=e93]:
                  - generic [ref=e94]: $150.00
                  - generic [ref=e95]: $180.00
              - link "Tom & Jerry -33% Tom & Jerry $200.00 $300.00" [ref=e96] [cursor=pointer]:
                - /url: /products/tom-jerry
                - generic [ref=e97]:
                  - img "Tom & Jerry" [ref=e98]
                  - generic [ref=e99]: "-33%"
                - paragraph [ref=e100]: Tom & Jerry
                - generic [ref=e101]:
                  - generic [ref=e102]: $200.00
                  - generic [ref=e103]: $300.00
              - link "key ring paws key ring paws $60.00 $60.00" [ref=e104] [cursor=pointer]:
                - /url: /products/key-ring-paws
                - img "key ring paws" [ref=e106]
                - paragraph [ref=e107]: key ring paws
                - generic [ref=e108]:
                  - generic [ref=e109]: $60.00
                  - generic [ref=e110]: $60.00
              - link "lamp 2 -38% lamp 2 $50.00 $80.00" [ref=e111] [cursor=pointer]:
                - /url: /products/lamp-2
                - generic [ref=e112]:
                  - img "lamp 2" [ref=e113]
                  - generic [ref=e114]: "-38%"
                - paragraph [ref=e115]: lamp 2
                - generic [ref=e116]:
                  - generic [ref=e117]: $50.00
                  - generic [ref=e118]: $80.00
              - link "lamp 1 -18% lamp 1 $99.00 $120.00" [ref=e119] [cursor=pointer]:
                - /url: /products/lamp-1
                - generic [ref=e120]:
                  - img "lamp 1" [ref=e121]
                  - generic [ref=e122]: "-18%"
                - paragraph [ref=e123]: lamp 1
                - generic [ref=e124]:
                  - generic [ref=e125]: $99.00
                  - generic [ref=e126]: $120.00
    - contentinfo [ref=e127]:
      - generic [ref=e128]:
        - generic [ref=e129]:
          - heading "STORE" [level=2] [ref=e130]
          - paragraph [ref=e131]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e132]:
            - link "IG" [ref=e133] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e134] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e135] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e136]:
          - heading "Shop" [level=3] [ref=e137]
          - list [ref=e138]:
            - listitem [ref=e139]:
              - link "All Products" [ref=e140] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e141]:
              - link "Tom & Jerry" [ref=e142] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e143]:
              - link "Hero's" [ref=e144] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e145]:
              - link "Lamps" [ref=e146] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e147]:
              - link "Key Ring" [ref=e148] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e149]:
              - link "Dogs" [ref=e150] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e151]:
          - heading "Account" [level=3] [ref=e152]
          - list [ref=e153]:
            - listitem [ref=e154]:
              - link "My Orders" [ref=e155] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e156]:
              - link "Wishlist" [ref=e157] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e158]:
              - link "My Profile" [ref=e159] [cursor=pointer]:
                - /url: /account
        - generic [ref=e160]:
          - heading "Support" [level=3] [ref=e161]
          - list [ref=e162]:
            - listitem [ref=e163]:
              - link "Contact Us" [ref=e164] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e165]:
              - link "FAQs" [ref=e166] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e167]:
              - link "Refund & Returns" [ref=e168] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e169]:
              - link "Shipping Info" [ref=e170] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e171]:
          - heading "Legal" [level=3] [ref=e172]
          - list [ref=e173]:
            - listitem [ref=e174]:
              - link "Privacy Policy" [ref=e175] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e176]:
              - link "Terms of Service" [ref=e177] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e178]:
        - paragraph [ref=e179]: © 2026 Store. All rights reserved.
        - generic [ref=e180]:
          - link "orders@aitalk247.com" [ref=e181] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e182] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e184]:
      - img [ref=e185]
  - button "Open Next.js Dev Tools" [ref=e192] [cursor=pointer]:
    - img [ref=e193]
  - alert [ref=e196]
```

# Test source

```ts
  1  | import { test, expect, devices } from '@playwright/test'
  2  | 
  3  | // Mobile-specific tests run with Pixel 5 device in playwright.config.ts
  4  | // These tests verify responsive layout behavior
  5  | 
  6  | test.describe('Mobile layout', () => {
  7  |   test('homepage renders on mobile', async ({ page }) => {
  8  |     await page.goto('/')
  9  |     await expect(page.locator('header')).toBeVisible()
  10 |   })
  11 | 
  12 |   test('products page hides sidebar filter on mobile', async ({ page }) => {
  13 |     await page.goto('/products')
  14 |     // Sidebar has hidden lg:block — should be hidden on mobile
  15 |     const sidebar = page.locator('aside')
> 16 |     await expect(sidebar).toBeHidden()
     |                           ^ Error: expect(locator).toBeHidden() failed
  17 |   })
  18 | 
  19 |   test('search page works on mobile', async ({ page }) => {
  20 |     await page.goto('/search')
  21 |     const input = page.locator('input').first()
  22 |     await expect(input).toBeVisible()
  23 |     await input.fill('test')
  24 |     await page.keyboard.press('Enter')
  25 |     await expect(page).toHaveURL(/q=test/)
  26 |   })
  27 | 
  28 |   test('product detail page renders on mobile', async ({ page }) => {
  29 |     await page.goto('/products')
  30 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  31 |     const href = await firstProduct.getAttribute('href')
  32 |     if (href) {
  33 |       await page.goto(href)
  34 |       await expect(page.locator('h1')).toBeVisible()
  35 |       // Add to cart button must be visible even on mobile
  36 |       await expect(page.locator('button', { hasText: /Add to Cart|Out of Stock/i }).first()).toBeVisible()
  37 |     }
  38 |   })
  39 | 
  40 |   test('cart page works on mobile', async ({ page }) => {
  41 |     await page.goto('/cart')
  42 |     // Either empty state or cart items
  43 |     const body = await page.content()
  44 |     expect(body.length).toBeGreaterThan(100)
  45 |   })
  46 | })
  47 | 
```