# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mobile.spec.ts >> Mobile layout >> search page works on mobile
- Location: e2e\mobile.spec.ts:19:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('input').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('input').first()
    9 × locator resolved to <input value="" type="text" placeholder="Search products..." class="flex-1 text-sm outline-none bg-transparent text-gray-700 placeholder-gray-400"/>
      - unexpected value "hidden"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]: Free Shipping on all Orders
    - banner [ref=e4]:
      - generic [ref=e5]:
        - button [ref=e6]:
          - img [ref=e7]
        - link "STORE" [ref=e8] [cursor=pointer]:
          - /url: /
        - generic [ref=e9]:
          - link [ref=e10] [cursor=pointer]:
            - /url: /search
            - img [ref=e11]
          - link [ref=e14] [cursor=pointer]:
            - /url: /cart
            - img [ref=e15]
          - button [ref=e19]:
            - img [ref=e21]
    - main [ref=e24]:
      - generic [ref=e25]:
        - generic [ref=e27]:
          - img [ref=e28]
          - textbox "Search products, categories…" [active] [ref=e31]
          - button "Search" [ref=e32]
        - generic [ref=e33]:
          - img [ref=e34]
          - paragraph [ref=e37]: Start typing to search products…
    - contentinfo [ref=e38]:
      - generic [ref=e39]:
        - generic [ref=e40]:
          - heading "STORE" [level=2] [ref=e41]
          - paragraph [ref=e42]: Quality products delivered to your door. Free shipping on orders above $499.
          - generic [ref=e43]:
            - link "IG" [ref=e44] [cursor=pointer]:
              - /url: "#"
            - link "TW" [ref=e45] [cursor=pointer]:
              - /url: "#"
            - link "FB" [ref=e46] [cursor=pointer]:
              - /url: "#"
        - generic [ref=e47]:
          - heading "Shop" [level=3] [ref=e48]
          - list [ref=e49]:
            - listitem [ref=e50]:
              - link "All Products" [ref=e51] [cursor=pointer]:
                - /url: /products
            - listitem [ref=e52]:
              - link "Tom & Jerry" [ref=e53] [cursor=pointer]:
                - /url: /category/tom-jerry
            - listitem [ref=e54]:
              - link "Hero's" [ref=e55] [cursor=pointer]:
                - /url: /category/hero-s
            - listitem [ref=e56]:
              - link "Lamps" [ref=e57] [cursor=pointer]:
                - /url: /category/lamps
            - listitem [ref=e58]:
              - link "Key Ring" [ref=e59] [cursor=pointer]:
                - /url: /category/key-ring
            - listitem [ref=e60]:
              - link "Dogs" [ref=e61] [cursor=pointer]:
                - /url: /category/dogs
        - generic [ref=e62]:
          - heading "Account" [level=3] [ref=e63]
          - list [ref=e64]:
            - listitem [ref=e65]:
              - link "My Orders" [ref=e66] [cursor=pointer]:
                - /url: /account/orders
            - listitem [ref=e67]:
              - link "Wishlist" [ref=e68] [cursor=pointer]:
                - /url: /wishlist
            - listitem [ref=e69]:
              - link "My Profile" [ref=e70] [cursor=pointer]:
                - /url: /account
        - generic [ref=e71]:
          - heading "Support" [level=3] [ref=e72]
          - list [ref=e73]:
            - listitem [ref=e74]:
              - link "Contact Us" [ref=e75] [cursor=pointer]:
                - /url: /contact
            - listitem [ref=e76]:
              - link "FAQs" [ref=e77] [cursor=pointer]:
                - /url: /faq
            - listitem [ref=e78]:
              - link "Refund & Returns" [ref=e79] [cursor=pointer]:
                - /url: /refund-policy
            - listitem [ref=e80]:
              - link "Shipping Info" [ref=e81] [cursor=pointer]:
                - /url: /shipping-policy
        - generic [ref=e82]:
          - heading "Legal" [level=3] [ref=e83]
          - list [ref=e84]:
            - listitem [ref=e85]:
              - link "Privacy Policy" [ref=e86] [cursor=pointer]:
                - /url: /privacy-policy
            - listitem [ref=e87]:
              - link "Terms of Service" [ref=e88] [cursor=pointer]:
                - /url: /terms
      - generic [ref=e89]:
        - paragraph [ref=e90]: © 2026 Store. All rights reserved.
        - generic [ref=e91]:
          - link "orders@aitalk247.com" [ref=e92] [cursor=pointer]:
            - /url: mailto:orders@aitalk247.com
          - link "support@aitalk247.com" [ref=e93] [cursor=pointer]:
            - /url: mailto:support@aitalk247.com
    - button "Open chat" [ref=e95]:
      - img [ref=e96]
  - button "Open Next.js Dev Tools" [ref=e103] [cursor=pointer]:
    - img [ref=e104]
  - alert [ref=e107]
```

# Test source

```ts
  1  | import { test, expect, devices } from '@playwright/test'
  2  | 
  3  | // Mobile-specific tests run with Pixel 5 device in playwright.config.ts
  4  | // These tests verify responsive layout behavior
  5  | 
  6  | test.describe('Mobile layout', () => {
  7  |   test('homepage renders on mobile', async ({ page }) => {
  8  |     await page.goto('/')
  9  |     await expect(page.locator('header')).toBeVisible()
  10 |   })
  11 | 
  12 |   test('products page hides sidebar filter on mobile', async ({ page }) => {
  13 |     await page.goto('/products')
  14 |     // Sidebar has hidden lg:block — should be hidden on mobile
  15 |     const sidebar = page.locator('aside')
  16 |     await expect(sidebar).toBeHidden()
  17 |   })
  18 | 
  19 |   test('search page works on mobile', async ({ page }) => {
  20 |     await page.goto('/search')
  21 |     const input = page.locator('input').first()
> 22 |     await expect(input).toBeVisible()
     |                         ^ Error: expect(locator).toBeVisible() failed
  23 |     await input.fill('test')
  24 |     await page.keyboard.press('Enter')
  25 |     await expect(page).toHaveURL(/q=test/)
  26 |   })
  27 | 
  28 |   test('product detail page renders on mobile', async ({ page }) => {
  29 |     await page.goto('/products')
  30 |     const firstProduct = page.locator('a[href^="/products/"]').first()
  31 |     const href = await firstProduct.getAttribute('href')
  32 |     if (href) {
  33 |       await page.goto(href)
  34 |       await expect(page.locator('h1')).toBeVisible()
  35 |       // Add to cart button must be visible even on mobile
  36 |       await expect(page.locator('button', { hasText: /Add to Cart|Out of Stock/i }).first()).toBeVisible()
  37 |     }
  38 |   })
  39 | 
  40 |   test('cart page works on mobile', async ({ page }) => {
  41 |     await page.goto('/cart')
  42 |     // Either empty state or cart items
  43 |     const body = await page.content()
  44 |     expect(body.length).toBeGreaterThan(100)
  45 |   })
  46 | })
  47 | 
```